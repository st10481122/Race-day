﻿
using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDay.API.Data;
using RaceDay.API.DTOs;
using RaceDay.API.Models;

namespace RaceDay.API.Controllers
{
    [ApiController]
    [Route("api")]
    [Authorize]
    public class ResultsController : ControllerBase
    {
        private readonly RaceDayContext _context;

        public ResultsController(RaceDayContext context)
        {
            _context = context;
        }

        private bool TryGetUserId(out int userId) =>
            int.TryParse(User.FindFirstValue(ClaimTypes.NameIdentifier),
                out userId);

        [HttpPost("events/{eventId:int}/results")]
        [Authorize(Roles = "Organiser")]
        public async Task<IActionResult> CreateResult(
            int eventId, ResultRequestDto dto)
        {
            if (!TryGetUserId(out int userId))
                return Unauthorized();

            var raceEvent = await _context.Events
                .FirstOrDefaultAsync(e => e.EventId == eventId);

            if (raceEvent == null)
                return NotFound(new { message = "Event not found." });

            if (raceEvent.OrganiserId != userId)
                return Forbid();

            var enrolment = await _context.Enrolments
                .Include(e => e.Category)
                .FirstOrDefaultAsync(e =>
                    e.EnrolmentId == dto.EnrolmentId);

            if (enrolment == null ||
                enrolment.Category == null ||
                enrolment.Category.EventId != eventId)
            {
                return BadRequest(new
                {
                    message = "The enrolment does not belong to this event."
                });
            }

            bool resultExists = await _context.Results
                .AnyAsync(r => r.EnrolmentId == dto.EnrolmentId);

            if (resultExists)
                return Conflict(new
                {
                    message = "A result already exists for this enrolment."
                });

            var result = new Result
            {
                EnrolmentId = dto.EnrolmentId,
                FinishTime = dto.FinishTime,
                Position = dto.Position,
                Remarks = dto.Remarks
            };

            _context.Results.Add(result);

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateException)
            {
                return Conflict(new
                {
                    message = "The result could not be saved. Check whether one already exists for this enrolment."
                });
            }

            return StatusCode(201, new
            {
                result.ResultId,
                result.EnrolmentId,
                result.FinishTime,
                result.Position,
                result.Remarks
            });
        }

        [HttpGet("results/my")]
        [Authorize(Roles = "Participant")]
        public async Task<IActionResult> GetMyResults()
        {
            if (!TryGetUserId(out int userId))
                return Unauthorized();

            var results = await _context.Results
                .AsNoTracking()
                .Where(r => r.Enrolment!.ParticipantId == userId)
                .Select(r => new
                {
                    r.ResultId,
                    r.EnrolmentId,
                    eventName = r.Enrolment!.Category!.Event!.EventName,
                    categoryName = r.Enrolment.Category.CategoryName,
                    r.FinishTime,
                    r.Position,
                    r.Remarks
                })
                .ToListAsync();

            return Ok(results);
        }

        [HttpGet("events/{eventId:int}/results")]
        [Authorize(Roles = "Organiser")]
        public async Task<IActionResult> GetEventResults(int eventId)
        {
            if (!TryGetUserId(out int userId))
                return Unauthorized();

            var raceEvent = await _context.Events
                .FirstOrDefaultAsync(e => e.EventId == eventId);

            if (raceEvent == null)
                return NotFound(new { message = "Event not found." });

            if (raceEvent.OrganiserId != userId)
                return Forbid();

            var results = await _context.Results
                .AsNoTracking()
                .Where(r => r.Enrolment!.Category!.EventId == eventId)
                .Select(r => new
                {
                    r.ResultId,
                    r.EnrolmentId,
                    participantName = r.Enrolment!.Participant!.FullName,
                    categoryName = r.Enrolment.Category!.CategoryName,
                    r.FinishTime,
                    r.Position,
                    r.Remarks
                })
                .OrderBy(r => r.Position)
                .ToListAsync();

            return Ok(results);
        }

        [HttpPut("results/{id:int}")]
        [Authorize(Roles = "Organiser")]
        public async Task<IActionResult> UpdateResult(
            int id, ResultRequestDto dto)
        {
            if (!TryGetUserId(out int userId))
                return Unauthorized();

            var result = await _context.Results
                .Include(r => r.Enrolment)
                    .ThenInclude(e => e!.Category)
                        .ThenInclude(c => c!.Event)
                .FirstOrDefaultAsync(r => r.ResultId == id);

            if (result == null)
                return NotFound(new { message = "Result not found." });

            if (result.Enrolment?.Category?.Event?.OrganiserId != userId)
                return Forbid();

            if (result.EnrolmentId != dto.EnrolmentId)
                return BadRequest(new
                {
                    message = "The enrolment linked to a result cannot be changed."
                });

            result.FinishTime = dto.FinishTime;
            result.Position = dto.Position;
            result.Remarks = dto.Remarks;

            await _context.SaveChangesAsync();

            return Ok(new
            {
                message = "Result updated successfully.",
                result.ResultId,
                result.EnrolmentId,
                result.FinishTime,
                result.Position,
                result.Remarks
            });
        }

        [HttpDelete("results/{id:int}")]
        [Authorize(Roles = "Organiser")]
        public async Task<IActionResult> DeleteResult(int id)
        {
            if (!TryGetUserId(out int userId))
                return Unauthorized();

            var result = await _context.Results
                .Include(r => r.Enrolment)
                    .ThenInclude(e => e!.Category)
                        .ThenInclude(c => c!.Event)
                .FirstOrDefaultAsync(r => r.ResultId == id);

            if (result == null)
                return NotFound(new { message = "Result not found." });

            if (result.Enrolment?.Category?.Event?.OrganiserId != userId)
                return Forbid();

            _context.Results.Remove(result);
            await _context.SaveChangesAsync();

            return NoContent();
        }
    }
}
