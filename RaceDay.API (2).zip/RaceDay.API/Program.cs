





using System.Security.Claims;

using System.Text;

using Microsoft.AspNetCore.Authentication.JwtBearer;

using Microsoft.AspNetCore.Identity;

using Microsoft.EntityFrameworkCore;

using Microsoft.IdentityModel.Tokens;

using RaceDay.API.Data;

using RaceDay.API.Models;



var builder = WebApplication.CreateBuilder(args);



builder.Services.AddControllers();

builder.Services.AddEndpointsApiExplorer();

builder.Services.AddSwaggerGen();



builder.Services.AddDbContext<RaceDayContext>(options =>

    options.UseSqlServer(

        builder.Configuration.GetConnectionString("RaceDayConnection")));



builder.Services.AddScoped<IPasswordHasher<User>, PasswordHasher<User>>();



var jwtKey = builder.Configuration["Jwt:Key"]

    ?? throw new InvalidOperationException("JWT key is missing.");



var signingKey = new SymmetricSecurityKey(

    Encoding.UTF8.GetBytes(jwtKey));



builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)

    .AddJwtBearer(options =>

    {

        options.TokenValidationParameters = new TokenValidationParameters

        {

            ValidateIssuer = true,

            ValidIssuer = builder.Configuration["Jwt:Issuer"],



            ValidateAudience = true,

            ValidAudience = builder.Configuration["Jwt:Audience"],



            ValidateIssuerSigningKey = true,

            IssuerSigningKey = signingKey,



            ValidateLifetime = true,

            ClockSkew = TimeSpan.FromSeconds(30),



            NameClaimType = ClaimTypes.Name,

            RoleClaimType = ClaimTypes.Role

        };

    });



builder.Services.AddAuthorization();



var app = builder.Build();



if (app.Environment.IsDevelopment())

{

    app.UseSwagger();

    app.UseSwaggerUI();

}



app.UseHttpsRedirection();



app.UseAuthentication();

app.UseAuthorization();



app.MapControllers();



app.Run();



public partial class Program { }

