﻿
using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDay.API.Data;
using RaceDay.API.DTOs;
using RaceDay.API.Models;

namespace RaceDay.API.Controllers
{
    [ApiController]
    [Route("api")]
    [Authorize]
    public class EnrolmentsController : ControllerBase
    {
        private readonly RaceDayContext _context;

        public EnrolmentsController(RaceDayContext context)
        {
            _context = context;
        }

        private bool TryGetUserId(out int userId) =>
            int.TryParse(User.FindFirstValue(ClaimTypes.NameIdentifier),
                out userId);

        [HttpPost("events/{eventId:int}/enrolments")]
        [Authorize(Roles = "Participant")]
        public async Task<IActionResult> CreateEnrolment(
            int eventId, EnrolmentRequestDto dto)
        {
            if (!TryGetUserId(out int userId))
                return Unauthorized();

            var category = await _context.Categories
                .FirstOrDefaultAsync(c =>
                    c.CategoryId == dto.CategoryId &&
                    c.EventId == eventId);

            if (category == null)
                return BadRequest(new
                {
                    message = "The category does not belong to this event."
                });

            var enrolment = new Enrolment
            {
                ParticipantId = userId,
                CategoryId = category.CategoryId,
                PaymentStatus = "Pending"
            };

            _context.Enrolments.Add(enrolment);

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateException)
            {
                return Conflict(new
                {
                    message = "You may already be enrolled in this category."
                });
            }

            return StatusCode(201, new
            {
                enrolment.EnrolmentId,
                enrolment.ParticipantId,
                enrolment.CategoryId,
                enrolment.EnrolmentDate,
                enrolment.PaymentStatus
            });
        }

        [HttpGet("enrolments/my")]
        [Authorize(Roles = "Participant")]
        public async Task<IActionResult> GetMyEnrolments()
        {
            if (!TryGetUserId(out int userId))
                return Unauthorized();

            var enrolments = await _context.Enrolments
                .AsNoTracking()
                .Where(e => e.ParticipantId == userId)
                .Select(e => new
                {
                    e.EnrolmentId,
                    e.CategoryId,
                    categoryName = e.Category!.CategoryName,
                    e.Category!.EventId,
                    eventName = e.Category.Event!.EventName,
                    e.EnrolmentDate,
                    e.PaymentStatus
                })
                .ToListAsync();

            return Ok(enrolments);
        }

        [HttpGet("events/{eventId:int}/enrolments")]
        [Authorize(Roles = "Organiser")]
        public async Task<IActionResult> GetEventEnrolments(int eventId)
        {
            if (!TryGetUserId(out int userId))
                return Unauthorized();

            var raceEvent = await _context.Events
                .FirstOrDefaultAsync(e => e.EventId == eventId);

            if (raceEvent == null)
                return NotFound(new { message = "Event not found." });

            if (raceEvent.OrganiserId != userId)
                return Forbid();

            var enrolments = await _context.Enrolments
                .AsNoTracking()
                .Where(e => e.Category!.EventId == eventId)
                .Select(e => new
                {
                    e.EnrolmentId,
                    e.ParticipantId,
                    participantName = e.Participant!.FullName,
                    e.CategoryId,
                    categoryName = e.Category!.CategoryName,
                    e.EnrolmentDate,
                    e.PaymentStatus
                })
                .ToListAsync();

            return Ok(enrolments);
        }

        [HttpDelete("enrolments/{id:int}")]
        [Authorize(Roles = "Participant")]
        public async Task<IActionResult> DeleteEnrolment(int id)
        {
            if (!TryGetUserId(out int userId))
                return Unauthorized();

            var enrolment = await _context.Enrolments
                .FirstOrDefaultAsync(e => e.EnrolmentId == id);

            if (enrolment == null)
                return NotFound(new { message = "Enrolment not found." });

            if (enrolment.ParticipantId != userId)
                return Forbid();

            _context.Enrolments.Remove(enrolment);

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateException)
            {
                return Conflict(new
                {
                    message = "This enrolment has a related result and cannot be deleted."
                });
            }

            return NoContent();
        }
    }
}
