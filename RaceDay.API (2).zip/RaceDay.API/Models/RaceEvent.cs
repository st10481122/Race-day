﻿using System.ComponentModel.DataAnnotations;

namespace RaceDay.API.Models
{
    public class RaceEvent
    {
        [Key]
        public int EventId { get; set; }

        [Required]
        [StringLength(200)]
        public string EventName { get; set; } = string.Empty;

        [Required]
        public DateTime EventDate { get; set; }

        [Required]
        [StringLength(200)]
        public string Location { get; set; } = string.Empty;

        public string? Description { get; set; }

        [Required]
        public int OrganiserId { get; set; }

        public DateTime CreatedAt { get; set; }

        public User? Organiser { get; set; }

        public ICollection<Category> Categories { get; set; }
            = new List<Category>();
    }
}
