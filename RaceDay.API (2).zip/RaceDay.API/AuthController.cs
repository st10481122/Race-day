﻿using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using RaceDay.API.Data;
using RaceDay.API.DTOs;
using RaceDay.API.Models;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;



namespace RaceDay.API.Controllers

{
    [ApiController]

    [Route("api/auth")]

    public class AuthController : ControllerBase

    {

        private readonly RaceDayContext _context;

        private readonly IPasswordHasher<User> _passwordHasher;

        private readonly IConfiguration _configuration;



        public AuthController(

            RaceDayContext context,

            IPasswordHasher<User> passwordHasher,

            IConfiguration configuration)

        {

            _context = context;

            _passwordHasher = passwordHasher;

            _configuration = configuration;

        }



        [HttpPost("register")]

        public async Task<IActionResult> Register(

            RegisterDtos request)

        {

            string email = request.Email.Trim().ToLowerInvariant();

            string roleName = request.Role.Trim();

            if (roleName != "Organiser" &&

                          roleName != "Participant")

            {

                return BadRequest(new

                {

                    message = "Role must be Organiser or Participant."

                });

            }



            bool emailExists = await _context.Users

                .AnyAsync(u => u.Email == email);



            if (emailExists)

            {

                return Conflict(new

                {

                    message = "An account with this email already exists."

                });

            }



            var role = await _context.Roles

                .FirstOrDefaultAsync(r => r.RoleName == roleName);



            if (role == null)

            {

                return StatusCode(500, new

                {

                    message = "The requested role is missing from the database."

                });

            }



            var user = new User

            {

                FullName = request.FullName.Trim(),

                Email = email,

                RoleId = role.RoleId

            };



            user.PasswordHash = _passwordHasher.HashPassword(

                user, request.Password);
            _context.Users.Add(user);

            await _context.SaveChangesAsync();



            return StatusCode(201, new

            {

                message = "Registration successful.",

                userId = user.UserId,

                fullName = user.FullName,

                email = user.Email,

                role = role.RoleName

            });

        }



        [HttpPost("login")]

        public async Task<IActionResult> Login(LoginRequest request)

        {

            string email = request.Email.Trim().ToLowerInvariant();

            var user = await _context.Users

                         .Include(u => u.Role)

                         .FirstOrDefaultAsync(u => u.Email == email);



            if (user == null || user.Role == null)

            {

                return Unauthorized(new

                {

                    message = "Invalid email or password."

                });

            }



            var verification = _passwordHasher.VerifyHashedPassword(

                user, user.PasswordHash, request.Password);



            if (verification == PasswordVerificationResult.Failed)

            {

                return Unauthorized(new

                {

                    message = "Invalid email or password."

                });

            }



            var expiresAt = DateTime.UtcNow.AddHours(2);



            var claims = new[]

            {

                new Claim(

                    ClaimTypes.NameIdentifier,

                    user.UserId.ToString()),



                new Claim(ClaimTypes.Name, user.FullName),

                new Claim(ClaimTypes.Email, user.Email),

                new Claim(ClaimTypes.Role, user.Role.RoleName)

            };



            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(

                    _configuration["Jwt:Key"]!));



            var credentials = new SigningCredentials(

                key, SecurityAlgorithms.HmacSha256);



            var token = new JwtSecurityToken(

                issuer: _configuration["Jwt:Issuer"],

                audience: _configuration["Jwt:Audience"],

                claims: claims,

                expires: expiresAt,

                signingCredentials: credentials);



            string tokenString =

                new JwtSecurityTokenHandler().WriteToken(token);



            return Ok(new AuthResponse

            {

                Token = tokenString,

                UserId = user.UserId,

                FullName = user.FullName,

                Email = user.Email,

                Role = user.Role.RoleName,

                ExpiresAt = expiresAt

            });

        }

    }

    public class RegisterDtos
    {
        public required string Email { get; set; }
        public required string FullName { get; set; }
        public required string Role { get; set; }
        public required string Password { get; set; }
    }
}