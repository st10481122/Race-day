﻿
using System.ComponentModel.DataAnnotations;

namespace RaceDay.API.DTOs
{
    public class EventRequestDto
    {
        [Required]
        [StringLength(200)]
        public string Name { get; set; } = string.Empty;

        public string? Description { get; set; }

        [Required]
        public DateTime EventDate { get; set; }

        [Required]
        [StringLength(200)]
        public string Location { get; set; } = string.Empty;
    }
}
