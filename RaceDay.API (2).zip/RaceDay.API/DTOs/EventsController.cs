﻿
using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDay.API.Data;
using RaceDay.API.DTOs;
using RaceDay.API.Models;

namespace RaceDay.API.Controllers
{
    [ApiController]
    [Route("api/events")]
    public class EventsController : ControllerBase
    {
        private readonly RaceDayContext _context;

        public EventsController(RaceDayContext context)
        {
            _context = context;
        }

        private bool TryGetUserId(out int userId)
        {
            return int.TryParse(
                User.FindFirstValue(ClaimTypes.NameIdentifier),
                out userId);
        }

        // GET: api/events
        // Public: shows upcoming events.
        [HttpGet]
        [AllowAnonymous]
        public async Task<IActionResult> GetUpcomingEvents()
        {
            var events = await _context.Events
                .AsNoTracking()
                .Where(e => e.EventDate >= DateTime.Now)
                .OrderBy(e => e.EventDate)
                .Select(e => new
                {
                    e.EventId,
                    name = e.EventName,
                    e.Description,
                    e.EventDate,
                    e.Location,
                    e.OrganiserId
                })
                .ToListAsync();

            return Ok(events);
        }

        // GET: api/events/1
        // Public: shows one event.
        [HttpGet("{id:int}")]
        [AllowAnonymous]
        public async Task<IActionResult> GetEvent(int id)
        {
            var raceEvent = await _context.Events
                .AsNoTracking()
                .Where(e => e.EventId == id)
                .Select(e => new
                {
                    e.EventId,
                    name = e.EventName,
                    e.Description,
                    e.EventDate,
                    e.Location,
                    e.OrganiserId
                })
                .FirstOrDefaultAsync();

            if (raceEvent == null)
                return NotFound(new { message = "Event not found." });

            return Ok(raceEvent);
        }

        // POST: api/events
        // Organisers only.
        [HttpPost]
        [Authorize(Roles = "Organiser")]
        public async Task<IActionResult> CreateEvent(
            EventRequestDto dto)
        {
            if (!TryGetUserId(out int userId))
                return Unauthorized();

            var raceEvent = new RaceEvent
            {
                EventName = dto.Name.Trim(),
                Description = dto.Description,
                EventDate = dto.EventDate,
                Location = dto.Location.Trim(),
                OrganiserId = userId
            };

            _context.Events.Add(raceEvent);
            await _context.SaveChangesAsync();

            return CreatedAtAction(
                nameof(GetEvent),
                new { id = raceEvent.EventId },
                new
                {
                    raceEvent.EventId,
                    name = raceEvent.EventName,
                    raceEvent.Description,
                    raceEvent.EventDate,
                    raceEvent.Location,
                    raceEvent.OrganiserId
                });
        }

        // PUT: api/events/1
        // Only the organiser who created the event can update it.
        [HttpPut("{id:int}")]
        [Authorize(Roles = "Organiser")]
        public async Task<IActionResult> UpdateEvent(
            int id, EventRequestDto dto)
        {
            if (!TryGetUserId(out int userId))
                return Unauthorized();

            var raceEvent = await _context.Events
                .FirstOrDefaultAsync(e => e.EventId == id);

            if (raceEvent == null)
                return NotFound(new { message = "Event not found." });

            if (raceEvent.OrganiserId != userId)
                return Forbid();

            raceEvent.EventName = dto.Name.Trim();
            raceEvent.Description = dto.Description;
            raceEvent.EventDate = dto.EventDate;
            raceEvent.Location = dto.Location.Trim();

            await _context.SaveChangesAsync();

            return Ok(new
            {
                message = "Event updated successfully.",
                raceEvent.EventId,
                name = raceEvent.EventName,
                raceEvent.Description,
                raceEvent.EventDate,
                raceEvent.Location
            });
        }

        // DELETE: api/events/1
        // Only the organiser who created the event can delete it.
        [HttpDelete("{id:int}")]
        [Authorize(Roles = "Organiser")]
        public async Task<IActionResult> DeleteEvent(int id)
        {
            if (!TryGetUserId(out int userId))
                return Unauthorized();

            var raceEvent = await _context.Events
                .FirstOrDefaultAsync(e => e.EventId == id);

            if (raceEvent == null)
                return NotFound(new { message = "Event not found." });

            if (raceEvent.OrganiserId != userId)
                return Forbid();

            _context.Events.Remove(raceEvent);

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateException)
            {
                return Conflict(new
                {
                    message = "This event cannot be deleted while it has related records, such as enrolments. Remove or resolve those records first."
                });
            }

            return NoContent();
        }
    }
}

