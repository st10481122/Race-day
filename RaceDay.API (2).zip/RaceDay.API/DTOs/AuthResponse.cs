﻿namespace RaceDay.API.DTOs

{

    public class AuthResponse

    {

        public string Token { get; set; } = string.Empty;



        public int UserId { get; set; }



        public string FullName { get; set; } = string.Empty;



        public string Email { get; set; } = string.Empty;



        public string Role { get; set; } = string.Empty;



        public DateTime ExpiresAt { get; set; }

    }

}