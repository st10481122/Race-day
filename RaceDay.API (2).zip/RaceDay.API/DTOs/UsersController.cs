﻿
using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDay.API.Data;
using RaceDay.API.DTOs;

namespace RaceDay.API.Controllers
{
    [ApiController]
    [Route("api/users/profile")]
    [Authorize]
    public class UsersController : ControllerBase
    {
        private readonly RaceDayContext _context;

        public UsersController(RaceDayContext context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<IActionResult> GetProfile()
        {
            var userIdText = User.FindFirstValue(ClaimTypes.NameIdentifier);

            if (!int.TryParse(userIdText, out int userId))
                return Unauthorized();

            var user = await _context.Users
                .Include(u => u.Role)
                .FirstOrDefaultAsync(u => u.UserId == userId);

            if (user == null)
                return NotFound(new { message = "User profile not found." });

            var nameParts = user.FullName
                .Split(' ', 2, StringSplitOptions.RemoveEmptyEntries);

            return Ok(new
            {
                user.UserId,
                firstName = nameParts.Length > 0 ? nameParts[0] : "",
                lastName = nameParts.Length > 1 ? nameParts[1] : "",
                user.Email,
                role = user.Role?.RoleName
            });
        }

        [HttpPut]
        public async Task<IActionResult> UpdateProfile(
            UpdateProfileDto dto)
        {
            var userIdText = User.FindFirstValue(ClaimTypes.NameIdentifier);

            if (!int.TryParse(userIdText, out int userId))
                return Unauthorized();

            var user = await _context.Users
                .FirstOrDefaultAsync(u => u.UserId == userId);

            if (user == null)
                return NotFound(new { message = "User profile not found." });

            string email = dto.Email.Trim().ToLowerInvariant();

            bool emailUsed = await _context.Users.AnyAsync(
                u => u.Email == email && u.UserId != userId);

            if (emailUsed)
                return Conflict(new
                {
                    message = "That email address is already in use."
                });

            user.FullName =
                $"{dto.FirstName.Trim()} {dto.LastName.Trim()}";
            user.Email = email;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateException)
            {
                return Conflict(new
                {
                    message = "The profile could not be updated. Check the email address."
                });
            }

            return Ok(new
            {
                message = "Profile updated successfully.",
                user.UserId,
                user.FullName,
                user.Email
            });
        }
    }
}
