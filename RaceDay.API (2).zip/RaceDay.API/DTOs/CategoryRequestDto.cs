﻿
using System.ComponentModel.DataAnnotations;

namespace RaceDay.API.DTOs
{
    public class CategoryRequestDto
    {
        [Required]
        [StringLength(100)]
        public string Name { get; set; } = string.Empty;

        [Range(typeof(decimal), "0.01", "9999.99")]
        public decimal Distance { get; set; }

        [Range(typeof(decimal), "0", "99999999.99")]
        public decimal EntryFee { get; set; }
    }
}
