﻿using Microsoft.EntityFrameworkCore;
using RaceDay.API.Models;

namespace RaceDay.API.Data
{
    public class RaceDayContext : DbContext
    {
        public RaceDayContext(DbContextOptions<RaceDayContext> options)
            : base(options)
        {
        }

        public DbSet<Role> Roles => Set<Role>();
        public DbSet<User> Users => Set<User>();
        public DbSet<RaceEvent> Events => Set<RaceEvent>();
        public DbSet<Category> Categories => Set<Category>();
        public DbSet<Enrolment> Enrolments => Set<Enrolment>();
        public DbSet<Result> Results => Set<Result>();

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<Role>()
                .ToTable("Roles");

            modelBuilder.Entity<Role>()
                .HasIndex(r => r.RoleName)
                .IsUnique();

            modelBuilder.Entity<User>()
                .ToTable("Users");

            modelBuilder.Entity<User>()
                .HasIndex(u => u.Email)
                .IsUnique();

            modelBuilder.Entity<User>()
                .HasOne(u => u.Role)
                .WithMany()
                .HasForeignKey(u => u.RoleId)
                .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<RaceEvent>()
                .ToTable("Events");

            modelBuilder.Entity<RaceEvent>()
                .Property(e => e.CreatedAt)
                .HasDefaultValueSql("GETDATE()");

            modelBuilder.Entity<RaceEvent>()
                .HasOne(e => e.Organiser)
                .WithMany()
                .HasForeignKey(e => e.OrganiserId)
                .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<Category>()
                .ToTable("Categories", table =>
                {
                    table.HasCheckConstraint(
                        "CK_Categories_Distance",
                        "[Distance] > 0");

                    table.HasCheckConstraint(
                        "CK_Categories_EntryFee",
                        "[EntryFee] >= 0");
                });

            modelBuilder.Entity<Category>()
                .Property(c => c.EntryFee)
                .HasDefaultValue(0);

            modelBuilder.Entity<Category>()
                .HasOne(c => c.Event)
                .WithMany(e => e.Categories)
                .HasForeignKey(c => c.EventId)
                .OnDelete(DeleteBehavior.Cascade);

            modelBuilder.Entity<Enrolment>()
                .ToTable("Enrolments", table =>
                {
                    table.HasCheckConstraint(
                        "CK_Enrolments_PaymentStatus",
                        "[PaymentStatus] IN ('Pending', 'Paid', 'Cancelled')");
                });

            modelBuilder.Entity<Enrolment>()
                .HasIndex(e => new
                {
                    e.ParticipantId,
                    e.CategoryId
                })
                .IsUnique();

            modelBuilder.Entity<Enrolment>()
                .Property(e => e.EnrolmentDate)
                .HasDefaultValueSql("GETDATE()");

            modelBuilder.Entity<Enrolment>()
                .Property(e => e.PaymentStatus)
                .HasDefaultValue("Pending");

            modelBuilder.Entity<Enrolment>()
                .HasOne(e => e.Participant)
                .WithMany()
                .HasForeignKey(e => e.ParticipantId)
                .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<Enrolment>()
                .HasOne(e => e.Category)
                .WithMany(c => c.Enrolments)
                .HasForeignKey(e => e.CategoryId)
                .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<Result>()
                .ToTable("Results", table =>
                {
                    table.HasCheckConstraint(
                        "CK_Results_Position",
                        "[Position] IS NULL OR [Position] > 0");
                });

            modelBuilder.Entity<Result>()
                .HasIndex(r => r.EnrolmentId)
                .IsUnique();

            modelBuilder.Entity<Result>()
                .HasOne(r => r.Enrolment)
                .WithOne(e => e.Result)
                .HasForeignKey<Result>(r => r.EnrolmentId)
                .OnDelete(DeleteBehavior.Restrict);
        }
    }
}
